
import { GoogleGenAI, Type } from "@google/genai";
import { GeneratedCopy, InspirationData } from "../types";

const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export interface CopywritingConfig {
  topic: string;
  style: string;
  opinions: string;
  keywords: string;
  trending: string;
}

export const generateXhsCopy = async (config: CopywritingConfig): Promise<GeneratedCopy> => {
  const ai = getAI();
  const { topic, style, opinions, keywords, trending } = config;
  
  const prompt = `你是一个顶级小红书爆款博主。请根据以下信息创作一篇极具传播力的笔记。
  
  核心信息：
  - 主题：${topic}
  - 文风/格调：${style}
  - 核心观点/内容：${opinions}
  - 关键特征/关键词：${keywords}
  - 追逐热点/趋势：${trending}
  
  写作要求：
  1. 标题（Title）：极其吸睛，善用数字、对比、悬念或情绪化表达。
  2. 开头（Hook）：第一句话必须能抓住读者注意力，制造共鸣或好奇心。
  3. 正文（Content）：分段清晰，语气亲切，大量使用符合小红书审美的emoji。
  4. 金句（Quotes）：提炼出2-3句易于传播、引发共鸣的短句。
  5. 互动引导（CTA）：设计一个自然且高回复率的结尾提问。
  6. 标签（Tags）：提供5-8个相关的热门话题标签。
  
  请以JSON格式输出：
  {
    "title": "爆款标题",
    "hook": "抓人开头",
    "content": "正文内容...",
    "quotes": ["金句1", "金句2"],
    "cta": "结尾引导",
    "tags": ["标签1", "标签2"]
  }`;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          hook: { type: Type.STRING },
          content: { type: Type.STRING },
          quotes: { type: Type.ARRAY, items: { type: Type.STRING } },
          cta: { type: Type.STRING },
          tags: { type: Type.ARRAY, items: { type: Type.STRING } }
        },
        required: ["title", "hook", "content", "quotes", "cta", "tags"]
      }
    }
  });

  return JSON.parse(response.text || '{}');
};

export interface CoverConfig {
  prompt: string;
  style: string;
  aspectRatio: "3:4" | "1:1" | "9:16";
  mainTitle?: string;
  keywords?: string[];
  imageData?: string; // base64
  mimeType?: string;
}

export const generateXhsCover = async (config: CoverConfig): Promise<string> => {
  const ai = getAI();
  const { prompt, style, aspectRatio, mainTitle, keywords, imageData, mimeType } = config;

  let styleModifier = "";
  if (style === "清新") styleModifier = "Fresh, airy, natural lighting, minimalist composition, soft colors, high-end lifestyle vlogging aesthetic.";
  if (style === "ins风") styleModifier = "High-end aesthetic, trendy, professional photography, magazine style, vibrant but balanced colors, urban and chic.";
  if (style === "教程风") styleModifier = "Clean, instructional, informative layout, high contrast, text-overlay ready composition, logically organized elements.";

  const textPrompt = `Create a viral Xiaohongshu cover image. 
  Style: ${styleModifier}. 
  Scene Description: ${prompt}.
  Core Topic/Title: ${mainTitle || 'None'}.
  Key Elements: ${keywords?.join(', ') || 'None'}.
  Composition: Optimized for ${aspectRatio} ratio, leaving space for text overlays, trendy and clickable.
  ${imageData ? 'Use the provided image as the primary reference for subject and composition, but enhance it to look like a professional social media post.' : ''}`;

  const parts: any[] = [{ text: textPrompt }];
  if (imageData && mimeType) {
    parts.push({
      inlineData: {
        data: imageData.split(',')[1] || imageData,
        mimeType: mimeType
      }
    });
  }

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: { parts },
    config: {
      imageConfig: {
        aspectRatio: aspectRatio
      }
    }
  });

  let imageUrl = '';
  for (const part of response.candidates?.[0]?.content?.parts || []) {
    if (part.inlineData) {
      imageUrl = `data:image/png;base64,${part.inlineData.data}`;
      break;
    }
  }

  if (!imageUrl) throw new Error("Failed to generate image");
  return imageUrl;
};

export const generateInspiration = async (field: string): Promise<InspirationData> => {
  const ai = getAI();
  const prompt = `分析当前小红书上“${field}”领域最热门的内容创作方向和选题。
  请提供5个具体的爆款选题，包含标题示例、内容核心逻辑和热度分(1-100)。
  
  请以JSON格式输出：
  {
    "field": "${field}",
    "topics": [
      { "title": "选题标题", "description": "核心逻辑/为什么火", "hotScore": 95 }
    ]
  }`;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          field: { type: Type.STRING },
          topics: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                description: { type: Type.STRING },
                hotScore: { type: Type.NUMBER }
              }
            }
          }
        }
      }
    }
  });

  return JSON.parse(response.text || '{}');
};
