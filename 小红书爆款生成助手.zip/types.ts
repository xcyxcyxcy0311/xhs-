
export enum ToolType {
  COPYWRITING = 'copywriting',
  COVER = 'cover',
  INSPIRATION = 'inspiration'
}

export interface GeneratedCopy {
  title: string;
  hook: string;
  content: string;
  quotes: string[];
  cta: string;
  tags: string[];
}

export interface GeneratedImage {
  url: string;
  prompt: string;
}

export interface InspirationTopic {
  title: string;
  description: string;
  hotScore: number;
}

export interface InspirationData {
  field: string;
  topics: InspirationTopic[];
}
