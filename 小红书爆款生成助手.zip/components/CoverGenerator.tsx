
import React, { useState, useRef } from 'react';
import { generateXhsCover, CoverConfig } from '../services/gemini';

const RATIOS = [
  { label: '3:4', sub: '黄金比例', value: '3:4' },
  { label: '1:1', sub: '正方形', value: '1:1' },
  { label: '9:16', sub: '全屏比例', value: '9:16' },
] as const;

const COVER_STYLES = [
  { label: '清新淡雅', value: '清新', emoji: '🌿', desc: '简约、明亮、充满自然氧气感' },
  { label: 'Ins高级感', value: 'ins风', emoji: '📸', desc: '时尚、滤镜感、大片视觉' },
  { label: '实用教程', value: '教程风', emoji: '📝', desc: '清晰、有条理、干货满满' },
];

enum CoverStep {
  UPLOAD,
  STYLE,
  CONFIG,
  RESULT
}

export const CoverGenerator: React.FC = () => {
  const [step, setStep] = useState<CoverStep>(CoverStep.UPLOAD);
  const [uploadedImage, setUploadedImage] = useState<{data: string, type: string} | null>(null);
  const [coverStyle, setCoverStyle] = useState('清新');
  const [config, setConfig] = useState({
    prompt: '',
    ratio: '3:4' as "3:4" | "1:1" | "9:16",
    mainTitle: '',
    keywords: ''
  });
  const [loading, setLoading] = useState(false);
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setUploadedImage({
          data: reader.result as string,
          type: file.type
        });
        setStep(CoverStep.STYLE);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleGenerate = async () => {
    setLoading(true);
    try {
      const finalConfig: CoverConfig = {
        prompt: config.prompt,
        style: coverStyle,
        aspectRatio: config.ratio,
        mainTitle: config.mainTitle,
        keywords: config.keywords.split(/[，, ]+/).filter(Boolean),
        imageData: uploadedImage?.data,
        mimeType: uploadedImage?.type
      };
      const url = await generateXhsCover(finalConfig);
      setImageUrl(url);
      setStep(CoverStep.RESULT);
    } catch (error) {
      console.error(error);
      alert('封面生成失败');
    } finally {
      setLoading(false);
    }
  };

  const reset = () => {
    setStep(CoverStep.UPLOAD);
    setUploadedImage(null);
    setImageUrl(null);
    setConfig({ prompt: '', ratio: '3:4', mainTitle: '', keywords: '' });
  };

  return (
    <div className="space-y-6">
      {/* Progress Bar */}
      <div className="flex justify-between items-center mb-4 px-2">
        {[CoverStep.UPLOAD, CoverStep.STYLE, CoverStep.CONFIG, CoverStep.RESULT].map((s, i) => (
          <div key={s} className="flex flex-col items-center flex-1">
             <div className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-black transition-all ${
               step === s ? 'xhs-bg-red text-white shadow-lg shadow-red-100 scale-125' : 
               step > s ? 'bg-green-400 text-white' : 'bg-gray-100 text-gray-300'
             }`}>
               {step > s ? '✓' : i + 1}
             </div>
             <span className={`text-[9px] mt-2 font-bold ${step === s ? 'xhs-text-red' : 'text-gray-300'}`}>
               {['上传素材', '选择风格', '详细配置', '生成结果'][i]}
             </span>
          </div>
        ))}
      </div>

      <div className="bg-white p-8 rounded-[32px] shadow-[0_8px_40px_rgb(0,0,0,0.04)] border border-gray-100 min-h-[400px] flex flex-col justify-center">
        
        {/* STEP 1: UPLOAD */}
        {step === CoverStep.UPLOAD && (
          <div className="text-center space-y-6 animate-fade-in">
            <div 
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-gray-100 hover:border-red-200 hover:bg-red-50/30 transition-all rounded-3xl p-12 cursor-pointer group"
            >
              <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-red-50 transition-colors">
                <svg className="w-10 h-10 text-gray-300 group-hover:text-red-400 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
              </div>
              <h4 className="text-lg font-black text-gray-800">上传底图/素材</h4>
              <p className="text-sm text-gray-400 mt-2">支持 JPG, PNG, WEBP (建议高清晰度)</p>
              <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" accept="image/*" />
            </div>
            <button 
              onClick={() => setStep(CoverStep.STYLE)}
              className="text-xs font-bold text-gray-400 hover:text-red-400 underline decoration-dotted"
            >
              跳过，直接描述画面
            </button>
          </div>
        )}

        {/* STEP 2: STYLE */}
        {step === CoverStep.STYLE && (
          <div className="animate-fade-in space-y-6">
            <h4 className="text-center text-xl font-black text-gray-900 mb-8">选择封面风格</h4>
            <div className="grid grid-cols-1 gap-4">
              {COVER_STYLES.map(s => (
                <button
                  key={s.value}
                  onClick={() => setCoverStyle(s.value)}
                  className={`flex items-center p-4 rounded-2xl border-2 transition-all text-left ${
                    coverStyle === s.value ? 'border-red-500 bg-red-50/50' : 'border-gray-50 hover:border-red-100 bg-white'
                  }`}
                >
                  <span className="text-4xl mr-5">{s.emoji}</span>
                  <div className="flex-1">
                    <p className={`font-black ${coverStyle === s.value ? 'xhs-text-red' : 'text-gray-800'}`}>{s.label}</p>
                    <p className="text-[10px] text-gray-400 font-bold uppercase tracking-tight">{s.desc}</p>
                  </div>
                  {coverStyle === s.value && <div className="w-5 h-5 xhs-bg-red rounded-full flex items-center justify-center text-white text-[10px]">✓</div>}
                </button>
              ))}
            </div>
            <button
              onClick={() => setStep(CoverStep.CONFIG)}
              className="w-full py-4 xhs-bg-red text-white rounded-2xl font-black text-lg shadow-xl shadow-red-100 mt-6 active:scale-95 transition-all"
            >
              下一步：详细配置
            </button>
          </div>
        )}

        {/* STEP 3: CONFIG */}
        {step === CoverStep.CONFIG && (
          <div className="animate-fade-in space-y-6">
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-lg font-black text-gray-900">详细配置</h4>
              <button onClick={() => setStep(CoverStep.STYLE)} className="text-[10px] font-bold text-gray-400 flex items-center">
                <svg className="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M15 19l-7-7 7-7" /></svg>
                重选风格
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-[10px] font-black text-gray-400 uppercase mb-2">封面主标题</label>
                <input
                  type="text"
                  value={config.mainTitle}
                  onChange={(e) => setConfig({...config, mainTitle: e.target.value})}
                  placeholder="例如：3天瘦5斤秘籍"
                  className="w-full px-5 py-3 rounded-xl bg-gray-50 border border-gray-100 focus:bg-white outline-none font-bold text-sm"
                />
              </div>

              <div>
                <label className="block text-[10px] font-black text-gray-400 uppercase mb-2">场景/画面补充描述</label>
                <textarea
                  rows={2}
                  value={config.prompt}
                  onChange={(e) => setConfig({...config, prompt: e.target.value})}
                  placeholder="例如：在晨光下的瑜伽垫旁，一杯燕麦奶..."
                  className="w-full px-5 py-3 rounded-xl bg-gray-50 border border-gray-100 focus:bg-white outline-none font-bold text-sm resize-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-black text-gray-400 uppercase mb-2">关键词 (逗号分隔)</label>
                  <input
                    type="text"
                    value={config.keywords}
                    onChange={(e) => setConfig({...config, keywords: e.target.value})}
                    placeholder="自律, 极简, 氛围感"
                    className="w-full px-5 py-3 rounded-xl bg-gray-50 border border-gray-100 focus:bg-white outline-none font-bold text-[11px]"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-black text-gray-400 uppercase mb-2">画幅比例</label>
                  <select 
                    value={config.ratio}
                    onChange={(e) => setConfig({...config, ratio: e.target.value as any})}
                    className="w-full px-4 py-3 rounded-xl bg-gray-50 border border-gray-100 focus:bg-white outline-none font-bold text-[11px] appearance-none"
                  >
                    {RATIOS.map(r => <option key={r.value} value={r.value}>{r.label} - {r.sub}</option>)}
                  </select>
                </div>
              </div>
            </div>

            <button
              onClick={handleGenerate}
              disabled={loading}
              className="w-full py-5 xhs-gradient text-white rounded-2xl font-black text-lg shadow-2xl shadow-red-200 mt-6 active:scale-95 transition-all disabled:opacity-50"
            >
              {loading ? (
                <span className="flex items-center justify-center">
                  <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
                  审美调配中...
                </span>
              ) : '一键生成爆款封面 🎨'}
            </button>
          </div>
        )}

        {/* STEP 4: RESULT */}
        {step === CoverStep.RESULT && (
          <div className="animate-fade-in text-center space-y-6">
            <div className="relative group overflow-hidden rounded-3xl bg-gray-50 shadow-inner">
               <img src={imageUrl!} alt="Result" className="w-full h-auto max-h-[500px] object-contain mx-auto transition-transform duration-700 group-hover:scale-105" />
               <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent pointer-events-none" />
            </div>
            <div className="flex gap-3">
              <a 
                href={imageUrl!} 
                download="xhs-viral-cover.png"
                className="flex-1 py-4 bg-gray-900 text-white rounded-2xl font-black text-sm shadow-xl active:scale-95 transition-all"
              >
                保存到相册
              </a>
              <button 
                onClick={reset}
                className="px-8 py-4 bg-gray-100 text-gray-500 rounded-2xl font-black text-sm hover:bg-gray-200 active:scale-95 transition-all"
              >
                重新开始
              </button>
            </div>
            <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">基于素材与 ${coverStyle} 风格创作完成</p>
          </div>
        )}

      </div>

      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: scale(0.98); }
          to { opacity: 1; transform: scale(1); }
        }
        .animate-fade-in {
          animation: fadeIn 0.4s cubic-bezier(0.16, 1, 0.3, 1) forwards;
        }
      `}</style>
    </div>
  );
};
