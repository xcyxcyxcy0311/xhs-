
import React, { useState } from 'react';
import { generateInspiration } from '../services/gemini';
import { InspirationData } from '../types';

const FIELDS = ['美妆', '穿搭', '美食', '旅行', '家居', '数码', '萌宠'];

export const InspirationGenerator: React.FC = () => {
  const [field, setField] = useState('');
  const [selectedField, setSelectedField] = useState(FIELDS[0]);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<InspirationData | null>(null);

  const handleGenerate = async (customField?: string) => {
    const target = customField || field || selectedField;
    if (!target) return;
    setLoading(true);
    try {
      const data = await generateInspiration(target);
      setResult(data);
    } catch (error) {
      console.error(error);
      alert('获取灵感失败');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      <div className="bg-white p-8 rounded-[32px] shadow-[0_8px_30px_rgb(0,0,0,0.04)] border border-gray-100 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-red-50 rounded-full blur-3xl -mr-16 -mt-16 opacity-50" />
        
        <label className="block text-xs font-black text-gray-400 uppercase tracking-widest mb-4">热点领域探测</label>
        <div className="flex flex-wrap gap-2.5 mb-8">
          {FIELDS.map(f => (
            <button
              key={f}
              onClick={() => {
                setSelectedField(f);
                handleGenerate(f);
              }}
              className={`px-5 py-2.5 rounded-2xl text-sm font-bold transition-all duration-300 ${
                selectedField === f 
                  ? 'xhs-bg-red text-white shadow-lg shadow-red-100 scale-105' 
                  : 'bg-gray-50 text-gray-500 hover:bg-gray-100 border border-gray-100'
              }`}
            >
              {f}
            </button>
          ))}
        </div>
        
        <div className="flex gap-3">
          <div className="relative flex-1">
            <input
              type="text"
              value={field}
              onChange={(e) => setField(e.target.value)}
              placeholder="搜索自定义话题，如：极简装修"
              className="w-full pl-5 pr-12 py-4 rounded-2xl bg-gray-50 border border-gray-100 focus:bg-white focus:ring-4 focus:ring-red-50 focus:border-red-200 transition-all outline-none text-sm font-bold"
            />
            <div className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-300">
               <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
            </div>
          </div>
          <button
            onClick={() => handleGenerate()}
            disabled={loading}
            className="px-8 py-4 xhs-bg-red text-white rounded-2xl font-black text-sm shadow-xl shadow-red-100 disabled:bg-gray-200 disabled:shadow-none transition-all active:scale-95"
          >
            {loading ? '探寻中...' : '搜索'}
          </button>
        </div>
      </div>

      {result && (
        <div className="space-y-5 animate-fade-in">
          <div className="flex items-center justify-between px-2">
            <h3 className="text-xl font-black text-gray-900 flex items-center">
              <span className="w-1.5 h-6 xhs-bg-red rounded-full mr-3" />
              {result.field} · 实时热议
            </h3>
            <span className="text-[10px] font-black text-gray-400 bg-gray-100 px-2 py-1 rounded-md">UPDATED TODAY</span>
          </div>
          <div className="grid gap-4">
            {result.topics.map((topic, i) => (
              <div key={i} className="bg-white p-6 rounded-[24px] shadow-sm border border-gray-50 hover:border-red-100 hover:shadow-xl hover:shadow-red-50 transition-all duration-300 group cursor-default">
                <div className="flex justify-between items-start mb-3">
                  <h4 className="text-lg font-black text-gray-800 group-hover:xhs-text-red transition-colors pr-4">{topic.title}</h4>
                  <div className="flex flex-col items-end shrink-0">
                     <span className="text-[10px] font-black text-red-400 mb-1">{topic.hotScore}% 热度</span>
                     <div className="w-16 h-1 bg-gray-100 rounded-full overflow-hidden">
                        <div className="h-full xhs-bg-red transition-all duration-1000 delay-300" style={{ width: `${topic.hotScore}%` }} />
                     </div>
                  </div>
                </div>
                <p className="text-sm text-gray-500 leading-relaxed font-medium mb-5">{topic.description}</p>
                <div className="flex items-center justify-between pt-4 border-t border-gray-50">
                  <span className="text-[10px] font-bold text-gray-300">建议风格：精致生活 / 避雷</span>
                  <button 
                    className="text-xs font-black xhs-text-red flex items-center px-4 py-2 bg-red-50 rounded-xl hover:bg-red-100 transition-colors"
                    onClick={() => {
                       alert('已为您锁定选题，点击导航中的“文案”即可开始创作！');
                    }}
                  >
                    以此创作 <svg className="ml-2 w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M14 5l7 7m0 0l-7 7m7-7H3" /></svg>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
