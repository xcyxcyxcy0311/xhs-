
import React, { useState } from 'react';
import { generateXhsCopy, CopywritingConfig } from '../services/gemini';
import { GeneratedCopy } from '../types';

const STYLES = ['精致生活', '避雷干货', '情绪价值', '穿搭美学', '好物分享', '职场干货'];

enum CopyStep {
  BASIC,
  OPINION,
  OPTIMIZE,
  RESULT
}

export const CopyGenerator: React.FC = () => {
  const [step, setStep] = useState<CopyStep>(CopyStep.BASIC);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<GeneratedCopy | null>(null);
  
  const [config, setConfig] = useState<CopywritingConfig>({
    topic: '',
    style: STYLES[0],
    opinions: '',
    keywords: '',
    trending: ''
  });

  const handleGenerate = async () => {
    setLoading(true);
    try {
      const data = await generateXhsCopy(config);
      setResult(data);
      setStep(CopyStep.RESULT);
    } catch (error) {
      console.error(error);
      alert('生成失败，请稍后重试');
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = () => {
    if (!result) return;
    const text = `${result.title}\n\n${result.hook}\n\n${result.content}\n\n金句：\n${result.quotes.join('\n')}\n\n${result.cta}\n\n${result.tags.map(t => '#' + t).join(' ')}`;
    navigator.clipboard.writeText(text);
    alert('复制成功！快去小红书发布吧 ✨');
  };

  const reset = () => {
    setStep(CopyStep.BASIC);
    setResult(null);
    setConfig({
      topic: '',
      style: STYLES[0],
      opinions: '',
      keywords: '',
      trending: ''
    });
  };

  return (
    <div className="space-y-6">
      {/* Progress Bar */}
      <div className="flex justify-between items-center mb-4 px-2">
        {[CopyStep.BASIC, CopyStep.OPINION, CopyStep.OPTIMIZE, CopyStep.RESULT].map((s, i) => (
          <div key={s} className="flex flex-col items-center flex-1">
             <div className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-black transition-all ${
               step === s ? 'xhs-bg-red text-white shadow-lg shadow-red-100 scale-125' : 
               step > s ? 'bg-green-400 text-white' : 'bg-gray-100 text-gray-300'
             }`}>
               {step > s ? '✓' : i + 1}
             </div>
             <span className={`text-[9px] mt-2 font-bold ${step === s ? 'xhs-text-red' : 'text-gray-300'}`}>
               {['主题风格', '核心观点', '关键词热点', '生成预览'][i]}
             </span>
          </div>
        ))}
      </div>

      <div className="bg-white p-8 rounded-[32px] shadow-[0_8px_40px_rgb(0,0,0,0.04)] border border-gray-100 min-h-[400px] flex flex-col justify-center">
        
        {/* STEP 1: BASIC INFO */}
        {step === CopyStep.BASIC && (
          <div className="animate-fade-in space-y-6">
            <h4 className="text-xl font-black text-gray-900 mb-6 text-center">确定主题与风格</h4>
            <div>
              <label className="block text-[10px] font-black text-gray-400 uppercase mb-3">笔记大标题 / 核心主题</label>
              <input
                type="text"
                value={config.topic}
                onChange={(e) => setConfig({...config, topic: e.target.value})}
                placeholder="例如：30天自律挑战计划"
                className="w-full px-6 py-4 rounded-2xl bg-gray-50 border border-gray-100 focus:bg-white focus:ring-4 focus:ring-red-50 focus:border-red-200 transition-all outline-none text-base font-bold text-gray-800"
              />
            </div>
            <div>
              <label className="block text-[10px] font-black text-gray-400 uppercase mb-3">文案格调</label>
              <div className="grid grid-cols-3 gap-2">
                {STYLES.map(s => (
                  <button
                    key={s}
                    onClick={() => setConfig({...config, style: s})}
                    className={`py-3 rounded-xl text-xs font-bold transition-all border ${
                      config.style === s 
                        ? 'xhs-bg-red text-white border-transparent shadow-lg shadow-red-100' 
                        : 'bg-white text-gray-500 border-gray-100 hover:border-red-100 hover:text-red-400'
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
            <button
              disabled={!config.topic}
              onClick={() => setStep(CopyStep.OPINION)}
              className="w-full py-4 xhs-bg-red text-white rounded-2xl font-black text-lg shadow-xl shadow-red-100 mt-6 active:scale-95 transition-all disabled:opacity-50"
            >
              下一步：填写观点
            </button>
          </div>
        )}

        {/* STEP 2: CORE OPINIONS */}
        {step === CopyStep.OPINION && (
          <div className="animate-fade-in space-y-6">
            <h4 className="text-xl font-black text-gray-900 mb-6 text-center">你想表达的观点</h4>
            <div>
              <label className="block text-[10px] font-black text-gray-400 uppercase mb-3">核心观点 / 想要分享的具体内容</label>
              <textarea
                rows={5}
                value={config.opinions}
                onChange={(e) => setConfig({...config, opinions: e.target.value})}
                placeholder="例如：1. 每天6点起床的重要性；2. 如何高效复盘；3. 坚持带来的心理变化..."
                className="w-full px-6 py-4 rounded-2xl bg-gray-50 border border-gray-100 focus:bg-white focus:ring-4 focus:ring-red-50 focus:border-red-200 transition-all outline-none text-base font-bold text-gray-800 resize-none leading-relaxed"
              />
            </div>
            <div className="flex gap-4">
              <button
                onClick={() => setStep(CopyStep.BASIC)}
                className="flex-1 py-4 bg-gray-100 text-gray-500 rounded-2xl font-black text-lg transition-all active:scale-95"
              >
                返回
              </button>
              <button
                disabled={!config.opinions}
                onClick={() => setStep(CopyStep.OPTIMIZE)}
                className="flex-[2] py-4 xhs-bg-red text-white rounded-2xl font-black text-lg shadow-xl shadow-red-100 active:scale-95 transition-all disabled:opacity-50"
              >
                下一步：优化细节
              </button>
            </div>
          </div>
        )}

        {/* STEP 3: OPTIMIZATION */}
        {step === CopyStep.OPTIMIZE && (
          <div className="animate-fade-in space-y-6">
            <h4 className="text-xl font-black text-gray-900 mb-6 text-center">细节优化与热点</h4>
            <div className="space-y-4">
              <div>
                <label className="block text-[10px] font-black text-gray-400 uppercase mb-3">目标关键词 (Capture Keywords)</label>
                <input
                  type="text"
                  value={config.keywords}
                  onChange={(e) => setConfig({...config, keywords: e.target.value})}
                  placeholder="例如：逆袭、干货、新手必看"
                  className="w-full px-6 py-4 rounded-2xl bg-gray-50 border border-gray-100 focus:bg-white outline-none font-bold text-sm"
                />
              </div>
              <div>
                <label className="block text-[10px] font-black text-gray-400 uppercase mb-3">热点追踪 (Trending Topics)</label>
                <input
                  type="text"
                  value={config.trending}
                  onChange={(e) => setConfig({...config, trending: e.target.value})}
                  placeholder="例如：春季自律挑战、沉浸式学习"
                  className="w-full px-6 py-4 rounded-2xl bg-gray-50 border border-gray-100 focus:bg-white outline-none font-bold text-sm"
                />
              </div>
            </div>
            <button
              onClick={handleGenerate}
              disabled={loading}
              className="w-full py-5 xhs-gradient text-white rounded-2xl font-black text-lg shadow-2xl shadow-red-200 mt-6 active:scale-95 transition-all disabled:opacity-50"
            >
              {loading ? (
                <span className="flex items-center justify-center space-x-2">
                   <div className="w-2 h-2 bg-white rounded-full animate-bounce" />
                   <div className="w-2 h-2 bg-white rounded-full animate-bounce [animation-delay:0.2s]" />
                   <div className="w-2 h-2 bg-white rounded-full animate-bounce [animation-delay:0.4s]" />
                   <span className="ml-2">AI 爆款引擎启动中...</span>
                </span>
              ) : '一键生成爆款文案 ✨'}
            </button>
            <button
              onClick={() => setStep(CopyStep.OPINION)}
              className="w-full text-xs font-bold text-gray-400 hover:text-red-400"
            >
              返回修改观点
            </button>
          </div>
        )}

        {/* STEP 4: RESULT */}
        {step === CopyStep.RESULT && result && (
          <div className="animate-fade-in space-y-6">
            <div className="flex items-center justify-between px-2">
              <h3 className="text-lg font-black text-gray-900">爆款预览</h3>
              <button onClick={copyToClipboard} className="text-[10px] font-black xhs-text-red bg-red-50 px-4 py-2 rounded-xl border border-red-100 active:scale-95 transition-all uppercase tracking-widest">
                复制全文 📋
              </button>
            </div>

            <div className="bg-gray-50/50 rounded-3xl border border-gray-100 overflow-hidden">
               <div className="p-6 space-y-6 bg-white">
                  <div>
                    <span className="inline-block px-2 py-0.5 bg-red-50 text-[10px] font-black xhs-text-red rounded uppercase tracking-tighter mb-2">爆款标题</span>
                    <p className="text-xl font-black text-gray-900 leading-tight">{result.title}</p>
                  </div>
                  <div className="space-y-3">
                    <p className="text-gray-800 font-bold leading-relaxed italic border-l-4 border-red-100 pl-4">
                      {result.hook}
                    </p>
                    <p className="text-gray-700 leading-relaxed whitespace-pre-wrap text-sm">
                      {result.content}
                    </p>
                  </div>
                  <div className="bg-amber-50/50 p-4 rounded-2xl border border-amber-100/50">
                    <span className="text-[10px] font-black text-amber-500 uppercase tracking-widest mb-2 block">传播金句</span>
                    <div className="space-y-2">
                      {result.quotes.map((q, i) => (
                        <p key={i} className="text-gray-900 text-[13px] font-black italic">“ {q} ”</p>
                      ))}
                    </div>
                  </div>
                  <div className="pt-4 border-t border-gray-50">
                    <p className="text-gray-900 font-black mb-3 text-sm">💬 {result.cta}</p>
                    <div className="flex flex-wrap gap-1.5">
                      {result.tags.map((tag, i) => (
                        <span key={i} className="text-blue-500 font-bold text-[11px] bg-blue-50 px-2 py-0.5 rounded-full">#{tag}</span>
                      ))}
                    </div>
                  </div>
               </div>
            </div>

            <button 
              onClick={reset}
              className="w-full py-4 bg-gray-100 text-gray-500 rounded-2xl font-black text-sm hover:bg-gray-200 active:scale-95 transition-all"
            >
              重新开始创作
            </button>
          </div>
        )}
      </div>

      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: scale(0.98); }
          to { opacity: 1; transform: scale(1); }
        }
        .animate-fade-in {
          animation: fadeIn 0.4s cubic-bezier(0.16, 1, 0.3, 1) forwards;
        }
      `}</style>
    </div>
  );
};
