
import React, { useState } from 'react';

interface AuthProps {
  onLogin: (email: string) => void;
}

export const Auth: React.FC<AuthProps> = ({ onLogin }) => {
  const [isLoginMode, setIsLoginMode] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      alert('请填写完整信息');
      return;
    }
    setIsLoading(true);
    // Simulate API call
    setTimeout(() => {
      onLogin(email);
      setIsLoading(false);
    }, 1200);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#fafbfc] px-4 relative overflow-hidden">
      {/* Abstract Background Shapes */}
      <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] xhs-bg-red opacity-[0.03] rounded-full blur-[100px]" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-blue-400 opacity-[0.03] rounded-full blur-[100px]" />

      <div className="max-w-md w-full animate-fade-in">
        {/* Logo Section */}
        <div className="text-center mb-10">
          <div className="w-16 h-16 xhs-bg-red rounded-2xl flex items-center justify-center text-white font-black text-3xl shadow-2xl shadow-red-200 mx-auto mb-4 rotate-6">
            R
          </div>
          <h2 className="text-2xl font-black text-gray-900 tracking-tight">
            {isLoginMode ? '欢迎回来' : '开启爆款之旅'}
          </h2>
          <p className="text-sm text-gray-400 font-medium mt-1">
            {isLoginMode ? '登录小红书爆款生成助手' : '创建你的博主专属 AI 工作台'}
          </p>
        </div>

        {/* Form Card */}
        <div className="bg-white p-8 rounded-[40px] shadow-[0_20px_60px_-15px_rgba(0,0,0,0.05)] border border-gray-100">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-1">
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">电子邮箱</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="hello@example.com"
                className="w-full px-6 py-4 rounded-2xl bg-gray-50 border border-transparent focus:bg-white focus:ring-4 focus:ring-red-50 focus:border-red-200 transition-all outline-none text-sm font-bold text-gray-800"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-1">密码</label>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full px-6 py-4 rounded-2xl bg-gray-50 border border-transparent focus:bg-white focus:ring-4 focus:ring-red-50 focus:border-red-200 transition-all outline-none text-sm font-bold text-gray-800"
              />
            </div>

            {isLoginMode && (
              <div className="text-right">
                <button type="button" className="text-[10px] font-black xhs-text-red hover:underline">忘记密码？</button>
              </div>
            )}

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-5 xhs-gradient text-white rounded-2xl font-black text-lg shadow-xl shadow-red-100 active:scale-[0.98] transition-all flex items-center justify-center"
            >
              {isLoading ? (
                <svg className="animate-spin h-5 w-5 text-white" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
              ) : (
                isLoginMode ? '立即登录' : '注册账号'
              )}
            </button>
          </form>

          {/* Switch Mode */}
          <div className="mt-8 text-center border-t border-gray-50 pt-6">
            <p className="text-xs text-gray-400 font-bold">
              {isLoginMode ? '还没有账号？' : '已经有账号了？'}
              <button 
                onClick={() => setIsLoginMode(!isLoginMode)}
                className="xhs-text-red ml-2 font-black hover:underline"
              >
                {isLoginMode ? '立即注册' : '点击登录'}
              </button>
            </p>
          </div>
        </div>

        {/* Trust Badge */}
        <div className="mt-12 text-center">
          <p className="text-[10px] text-gray-300 font-black uppercase tracking-[0.2em] mb-4">Trusted by 10,000+ Creators</p>
          <div className="flex justify-center items-center space-x-6 grayscale opacity-30">
             <span className="text-xs font-black">BEAUTY</span>
             <span className="text-xs font-black">FASHION</span>
             <span className="text-xs font-black">LIFESTYLE</span>
             <span className="text-xs font-black">TECH</span>
          </div>
        </div>
      </div>
    </div>
  );
};
