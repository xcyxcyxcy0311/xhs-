
import React, { useState } from 'react';
import { ToolType } from './types';
import { CopyGenerator } from './components/CopyGenerator';
import { CoverGenerator } from './components/CoverGenerator';
import { InspirationGenerator } from './components/InspirationGenerator';
import { Auth } from './components/Auth';

const App: React.FC = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [activeTab, setActiveTab] = useState<ToolType>(ToolType.INSPIRATION);
  const [user, setUser] = useState<{ email: string } | null>(null);

  const tabs = [
    { id: ToolType.INSPIRATION, label: '选题灵感', icon: '🔥' },
    { id: ToolType.COPYWRITING, label: '文案生成', icon: '✍️' },
    { id: ToolType.COVER, label: '封面设计', icon: '🎨' },
  ];

  const handleLogin = (email: string) => {
    setUser({ email });
    setIsLoggedIn(true);
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setUser(null);
  };

  if (!isLoggedIn) {
    return <Auth onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-[#FDFDFD] pb-24">
      {/* Dynamic Background Element */}
      <div className="fixed top-0 left-0 w-full h-64 bg-gradient-to-b from-red-50/50 to-transparent pointer-events-none -z-10" />

      {/* Header */}
      <header className="sticky top-0 z-50 glass-effect border-b border-gray-100/50 px-4">
        <div className="max-w-xl mx-auto py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-9 h-9 xhs-bg-red rounded-xl flex items-center justify-center text-white font-black text-xl shadow-lg shadow-red-200 rotate-3">
              R
            </div>
            <div>
              <h1 className="text-lg font-black tracking-tight text-gray-900 leading-none">
                小红书<span className="xhs-text-red">爆款生成助手</span>
              </h1>
              <p className="text-[10px] text-gray-400 font-bold uppercase tracking-tighter">AI Viral Studio</p>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <div className="hidden sm:flex px-3 py-1 bg-red-50 rounded-full">
              <span className="text-[10px] font-bold xhs-text-red">PRO 版已开启</span>
            </div>
            <button 
              onClick={handleLogout}
              className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center text-gray-400 hover:text-red-500 hover:bg-red-50 transition-all border border-gray-200"
              title="退出登录"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M17 16l4-4m0 0l-4-4m4-4H3" />
              </svg>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-xl mx-auto px-4 pt-8">
        {/* Modern Segmented Control / Tab Switcher */}
        <div className="bg-gray-100/80 p-1.5 rounded-2xl mb-10 flex shadow-inner border border-gray-200/50 backdrop-blur-sm">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex-1 py-3 px-2 rounded-xl text-sm font-black transition-all duration-300 flex items-center justify-center space-x-2 ${
                activeTab === tab.id
                  ? 'bg-white text-gray-900 shadow-md transform scale-[1.02]'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              <span className="text-base">{tab.icon}</span>
              <span className="hidden sm:inline">{tab.label}</span>
              <span className="sm:hidden">{tab.label.substring(0, 2)}</span>
            </button>
          ))}
        </div>

        {/* Component Display with Transition Effect */}
        <div className="animate-fade-in transition-all duration-500 min-h-[500px]">
          {activeTab === ToolType.INSPIRATION && (
            <div className="space-y-4">
              <div className="mb-6">
                <h2 className="text-2xl font-black text-gray-900">找寻今天的流量密码 🔍</h2>
                <p className="text-sm text-gray-400 font-medium">输入你的领域，看看现在什么最火</p>
              </div>
              <InspirationGenerator />
            </div>
          )}
          
          {activeTab === ToolType.COPYWRITING && (
            <div className="space-y-4">
              <div className="mb-6">
                <h2 className="text-2xl font-black text-gray-900">让 AI 为你润色创作 ✨</h2>
                <p className="text-sm text-gray-400 font-medium">从主题到正文，每一个字都是为了转化</p>
              </div>
              <CopyGenerator />
            </div>
          )}
          
          {activeTab === ToolType.COVER && (
            <div className="space-y-4">
              <div className="mb-6">
                <h2 className="text-2xl font-black text-gray-900">生成神仙级封面 📸</h2>
                <p className="text-sm text-gray-400 font-medium">视觉审美是小红书的第一生产力</p>
              </div>
              <CoverGenerator />
            </div>
          )}
        </div>

        {/* Footer Info Section */}
        <footer className="mt-20 py-10 border-t border-gray-100 text-center">
          <div className="inline-flex items-center space-x-4 grayscale opacity-40 mb-4">
            <span className="text-xs font-bold text-gray-400">Powered by Gemini 2.5</span>
            <span className="w-1 h-1 bg-gray-300 rounded-full"></span>
            <span className="text-xs font-bold text-gray-400">High Aesthetic UI</span>
          </div>
          <p className="text-[10px] text-gray-300 font-medium leading-loose max-w-xs mx-auto">
            请遵守社区创作规范，生成的内容仅供参考。<br/>
            © 2025 小红书爆款生成助手 - 你的私人内容专家
          </p>
        </footer>
      </main>

      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in {
          animation: fadeIn 0.4s ease-out forwards;
        }
      `}</style>
    </div>
  );
};

export default App;
